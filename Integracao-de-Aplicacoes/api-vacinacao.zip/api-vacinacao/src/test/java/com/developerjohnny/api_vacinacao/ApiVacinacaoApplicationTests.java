package com.developerjohnny.api_vacinacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVacinacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
